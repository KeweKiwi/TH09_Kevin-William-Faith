﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH09_Kevin_William_Faith
{
    internal class Item
    {
        private string name;
        private int price;
        private string url;
        private string type;

        public Item(string name, int price, string url, string type)
        {
            this.Name = name;
            this.Price = price;
            this.Url = url;
            this.Type = type;
        }

        public string Name { get => name; set => name = value; }
        public int Price { get => price; set => price = value; }
        public string Url { get => url; set => url = value; }
        public string Type { get => type; set => type = value; }
    }
}
