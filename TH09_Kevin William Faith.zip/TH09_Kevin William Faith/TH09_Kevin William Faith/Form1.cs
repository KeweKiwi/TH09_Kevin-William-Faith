﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH09_Kevin_William_Faith
{
    public partial class Form1 : Form
    {
        List<PictureBox> lpb = new List<PictureBox>();
        List<Label> lblNamaBarang = new List<Label>();
        List<Label> lblHargaBarang = new List<Label>();
        List <Button> listBtn = new List< Button>();
        DataTable dt = new DataTable();

        const int maxCol = 3;
        const int pbWidth = 150;
        const int pbHeight = 150;
        const int horizontalSpacing = 20;
        const int verticalSpacing = 70;
        int curRow = 0;
        int curCol = 0;
        int subTotal = 0;
        int coba = 0;

        List<Item> listItem;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblUploadImage.Visible = false;
            btnUpload.Visible = false;
            pbAdd.Visible = false;
            lblAddItem.Visible = false;
            tbAddName.Visible = false;
            tbAddPrice.Visible = false;
            lblItemPrice.Visible = false;
            btnAddCart.Visible = false;

            Item item1 = new Item("T-Shirt Kerah Bulat", 120000, "tshirtkerahbulat.jpg", "T-Shirts");
            Item item2 = new Item("Airism T-Shirt", 150000, "airism.jpg", "T-Shirts");
            Item item3 = new Item("T-Shirt Vneck", 170000, "vneck.jpg", "T-Shirts");

            Item item4 = new Item("Navy Shirt", 250000, "shirts1.jpeg", "Shirts");
            Item item5 = new Item("Blue Shirt", 300000, "blueshirt.jpg", "Shirts");
            Item item6 = new Item("Gray Shirt", 180000, "gray.jpeg", "Shirts");

            Item item7 = new Item("Gray Short Pants", 150000, "shortpants1.jpg", "Pants");
            Item item8 = new Item("Blue Short Pants", 180000, "blueshortpants.jpg", "Pants");
            Item item9 = new Item("Red Short Pants", 200000, "redshortpants.jpg", "Pants");

            Item item10 = new Item("Blue Long Pants", 120000, "longpants1.jpg", "Long Pants");
            Item item11 = new Item("Plaid Long pants", 150000, "plaidlong.jpg", "Long Pants");
            Item item12 = new Item("White Plaid Pants", 170000, "whiteplaid.jpeg", "Long Pants");

            Item item13 = new Item("Astroboy", 3000000, "shoes1.jpg", "Shoes");
            Item item14 = new Item("Sepatu Kuda", 1500000, "sepatukuda.jpg", "Shoes");
            Item item15 = new Item("Sepatu Realistis", 500000, "sepatureal.jpeg", "Shoes");

            Item item16 = new Item("Chickens feet", 120000, "jewelleries1.jpg", "Jewelleries");
            Item item17 = new Item("Spiderman Bracelet", 150000, "spidermanbracelet.jpg", "Jewelleries");
            Item item18 = new Item("Heart Earrings", 170000, "heartear.jpg", "Jewelleries");

            listItem = new List<Item>() { item1, item2, item3, item4, item5, item6, item7, item8, item9,item10, item11, item12, item13, item14, item15, item16, item17, item18};

            dt.Columns.Add("Item Name");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Price");
            dt.Columns.Add("Total");

            dgCart.DataSource=dt;
        }

        private void tShirtsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteObject();
            lblUploadImage.Visible = false;
            btnUpload.Visible = false;
            pbAdd.Visible = false;
            lblAddItem.Visible = false;
            tbAddName.Visible = false;
            tbAddPrice.Visible = false;
            lblItemPrice.Visible = false;
            btnAddCart.Visible = false;
            string currentDirectory = Directory.GetCurrentDirectory();
            foreach (Item item in listItem)
            {
                if(item.Type == "T-Shirts")
                {
                    // Generate object baru pake code
                    PictureBox picture = new PictureBox();
                    string absolutePath = Path.Combine(currentDirectory, "gambar/" + item.Url);
                    picture.Image = Image.FromFile(absolutePath);
                    picture.SizeMode = PictureBoxSizeMode.StretchImage;
                    picture.Size = new Size(pbWidth, pbHeight);
                    picture.Location = new Point(curCol * (pbWidth + horizontalSpacing), curRow * (pbHeight + verticalSpacing));
                    lpb.Add(picture);

                    Label label = new Label();
                    label.Text = item.Name;
                    label.Location = new Point(curCol * (pbWidth + horizontalSpacing), (picture.Location.Y + pbHeight));
                    lblNamaBarang.Add(label);

                    Label labelPrice = new Label();
                    labelPrice.Text = item.Price.ToString();
                    labelPrice.Location = new Point(curCol * (pbWidth + horizontalSpacing), (label.Location.Y + label.Size.Height));
                    lblHargaBarang.Add(labelPrice);
                   

                    Button btnAddToCart = new Button();
                    btnAddToCart.Text = "Add to Cart";
                    btnAddToCart.Location = new Point(curCol * (pbWidth + horizontalSpacing), (labelPrice.Location.Y + label.Size.Height));
                    listBtn.Add(btnAddToCart);

                    //Bikin even handler pake lambda function
                    btnAddToCart.Click += (senders, events) =>
                    {
                        bool checkExist = false;
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            if (dt.Rows[i]["Item Name"].ToString() == item.Name)
                            {
                                int qty = Convert.ToInt32(dt.Rows[i]["Quantity"]) + 1;
                                dt.Rows[i]["Quantity"] = qty;
                                dt.Rows[i]["Total"] = qty * item.Price;

                                checkExist = true;
                                break;
                            }
                        }
                        if (!checkExist)
                        {
                            dt.Rows.Add(item.Name, 1, item.Price, item.Price);
                        }
                        dgCart.DataSource = dt;
                        CalSubTotal();
                    };

                    // masukin object ke form
                    this.Controls.Add(picture);
                    this.Controls.Add(label);
                    this.Controls.Add(labelPrice);
                    this.Controls.Add(btnAddToCart);

                    curCol++;

                    if(curCol>= maxCol)
                    {
                        curCol = 0;
                        curRow++;
                    }
                }
            }
        }

        private void CalSubTotal()
        {
            subTotal = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                subTotal += Convert.ToInt32(dt.Rows[i]["Total"]);
            }
            tbSub.Text = subTotal.ToString();
            tbTot.Text = (subTotal * 1.1).ToString();
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteObject();
            lblUploadImage.Visible = true;
            btnUpload.Visible = true;
            pbAdd.Visible = true;
            lblAddItem.Visible = true;
            tbAddName.Visible = true;
            tbAddPrice.Visible = true;
            lblItemPrice.Visible = true;
            btnAddCart.Visible = true;

            tbAddName.Enabled = false;
            tbAddPrice.Enabled = false;
            btnAddCart.Enabled = false;

        }

      

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.jpg, *.png, *.bmp)|*.jpg; *.png; *.bmp|All files (.)|*.*";
            openFileDialog.Multiselect = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pbAdd.Image = Image.FromFile(openFileDialog.FileName);
                tbAddName.Enabled = true;
                tbAddPrice.Enabled = true;
            }
        }

        private void tbAddPrice_TextChanged(object sender, EventArgs e)
        {
            if (tbAddPrice.Text != "" && tbAddPrice.Text != "")
            {
                btnAddCart.Enabled = true;
            }
            else
            {
                btnAddCart.Enabled = false;
            }
        }

        private void tbAddName_TextChanged(object sender, EventArgs e)
        {
            if (tbAddPrice.Text != "" && tbAddPrice.Text != "")
            {
                btnAddCart.Enabled = true;
            }
            else
            {
                btnAddCart.Enabled = false;
            }
        }

        private void tbAddPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnAddCart_Click(object sender, EventArgs e)
        {
            bool checkExist = false;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["Item Name"].ToString() == tbAddName.Text)
                {
                    int qty = Convert.ToInt32(dt.Rows[i]["Quantity"]) + 1;
                    dt.Rows[i]["Quantity"] = qty;
                    dt.Rows[i]["Total"] = qty * int.Parse(tbAddPrice.Text);

                    checkExist = true;
                    break;
                }
            }
            if (!checkExist)
            {
                dt.Rows.Add(tbAddName.Text, 1, int.Parse(tbAddPrice.Text), int.Parse(tbAddPrice.Text));
            }
            dgCart.DataSource = dt;
            CalSubTotal();
            tbAddName.Clear();
            tbAddPrice.Clear();
        }

        private void DeleteObject()
        {
            curCol = 0;
            curRow = 0;
            for(int i = 0; i < listBtn.Count; i++)
            {
                this.Controls.Remove(lpb[i]);
                this.Controls.Remove(lblNamaBarang[i]);
                this.Controls.Remove(lblHargaBarang[i]);
                this.Controls.Remove(listBtn[i]);
            }
        }

        private void shirtsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteObject();
            lblUploadImage.Visible = false;
            btnUpload.Visible = false;
            pbAdd.Visible = false;
            lblAddItem.Visible = false;
            tbAddName.Visible = false;
            tbAddPrice.Visible = false;
            lblItemPrice.Visible = false;
            btnAddCart.Visible = false;
            lblUploadImage.Visible = false;
            btnUpload.Visible = false;
            pbAdd.Visible = false;
            lblAddItem.Visible = false;
            tbAddName.Visible = false;
            tbAddPrice.Visible = false;
            lblItemPrice.Visible = false;
            btnAddCart.Visible = false;
            string currentDirectory = Directory.GetCurrentDirectory();
            foreach (Item item in listItem)
            {
                if (item.Type == "Shirts")
                {
                    // Generate object baru pake code
                    PictureBox picture = new PictureBox();
                    string absolutePath = Path.Combine(currentDirectory, "gambar/" + item.Url);
                    picture.Image = Image.FromFile(absolutePath);
                    picture.SizeMode = PictureBoxSizeMode.StretchImage;
                    picture.Size = new Size(pbWidth, pbHeight);
                    picture.Location = new Point(curCol * (pbWidth + horizontalSpacing), curRow * (pbHeight + verticalSpacing));
                    lpb.Add(picture);

                    Label label = new Label();
                    label.Text = item.Name;
                    label.Location = new Point(curCol * (pbWidth + horizontalSpacing), (picture.Location.Y + pbHeight));
                    lblNamaBarang.Add(label);

                    Label labelPrice = new Label();
                    labelPrice.Text = item.Price.ToString();
                    labelPrice.Location = new Point(curCol * (pbWidth + horizontalSpacing), (label.Location.Y + label.Size.Height));
                    lblHargaBarang.Add(labelPrice);


                    Button btnAddToCart = new Button();
                    btnAddToCart.Text = "Add to Cart";
                    btnAddToCart.Location = new Point(curCol * (pbWidth + horizontalSpacing), (labelPrice.Location.Y + label.Size.Height));
                    listBtn.Add(btnAddToCart);

                    //Bikin even handler pake lambda function
                    btnAddToCart.Click += (senders, events) =>
                    {
                        bool checkExist = false;
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            if (dt.Rows[i]["Item Name"].ToString() == item.Name)
                            {
                                int qty = Convert.ToInt32(dt.Rows[i]["Quantity"]) + 1;
                                dt.Rows[i]["Quantity"] = qty;
                                dt.Rows[i]["Total"] = qty * item.Price;

                                checkExist = true;
                                break;
                            }
                        }
                        if (!checkExist)
                        {
                            dt.Rows.Add(item.Name, 1, item.Price, item.Price);
                        }
                        dgCart.DataSource = dt;
                        CalSubTotal();
                    };

                    // masukin object ke form
                    this.Controls.Add(picture);
                    this.Controls.Add(label);
                    this.Controls.Add(labelPrice);
                    this.Controls.Add(btnAddToCart);

                    curCol++;

                    if (curCol >= maxCol)
                    {
                        curCol = 0;
                        curRow++;
                    }
                }
            }
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteObject();
            lblUploadImage.Visible = false;
            btnUpload.Visible = false;
            pbAdd.Visible = false;
            lblAddItem.Visible = false;
            tbAddName.Visible = false;
            tbAddPrice.Visible = false;
            lblItemPrice.Visible = false;
            btnAddCart.Visible = false;
            string currentDirectory = Directory.GetCurrentDirectory();
            foreach (Item item in listItem)
            {
                if (item.Type == "Pants")
                {
                    // Generate object baru pake code
                    PictureBox picture = new PictureBox();
                    string absolutePath = Path.Combine(currentDirectory, "gambar/" + item.Url);
                    picture.Image = Image.FromFile(absolutePath);
                    picture.SizeMode = PictureBoxSizeMode.StretchImage;
                    picture.Size = new Size(pbWidth, pbHeight);
                    picture.Location = new Point(curCol * (pbWidth + horizontalSpacing), curRow * (pbHeight + verticalSpacing));
                    lpb.Add(picture);

                    Label label = new Label();
                    label.Text = item.Name;
                    label.Location = new Point(curCol * (pbWidth + horizontalSpacing), (picture.Location.Y + pbHeight));
                    lblNamaBarang.Add(label);

                    Label labelPrice = new Label();
                    labelPrice.Text = item.Price.ToString();
                    labelPrice.Location = new Point(curCol * (pbWidth + horizontalSpacing), (label.Location.Y + label.Size.Height));
                    lblHargaBarang.Add(labelPrice);


                    Button btnAddToCart = new Button();
                    btnAddToCart.Text = "Add to Cart";
                    btnAddToCart.Location = new Point(curCol * (pbWidth + horizontalSpacing), (labelPrice.Location.Y + label.Size.Height));
                    listBtn.Add(btnAddToCart);

                    //Bikin even handler pake lambda function
                    btnAddToCart.Click += (senders, events) =>
                    {
                        bool checkExist = false;
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            if (dt.Rows[i]["Item Name"].ToString() == item.Name)
                            {
                                int qty = Convert.ToInt32(dt.Rows[i]["Quantity"]) + 1;
                                dt.Rows[i]["Quantity"] = qty;
                                dt.Rows[i]["Total"] = qty * item.Price;

                                checkExist = true;
                                break;
                            }
                        }
                        if (!checkExist)
                        {
                            dt.Rows.Add(item.Name, 1, item.Price, item.Price);
                        }
                        dgCart.DataSource = dt;
                        CalSubTotal();
                    };

                    // masukin object ke form
                    this.Controls.Add(picture);
                    this.Controls.Add(label);
                    this.Controls.Add(labelPrice);
                    this.Controls.Add(btnAddToCart);

                    curCol++;

                    if (curCol >= maxCol)
                    {
                        curCol = 0;
                        curRow++;
                    }
                }
            }
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteObject();
            lblUploadImage.Visible = false;
            btnUpload.Visible = false;
            pbAdd.Visible = false;
            lblAddItem.Visible = false;
            tbAddName.Visible = false;
            tbAddPrice.Visible = false;
            lblItemPrice.Visible = false;
            btnAddCart.Visible = false;
            string currentDirectory = Directory.GetCurrentDirectory();
            foreach (Item item in listItem)
            {
                if (item.Type == "Long Pants")
                {
                    // Generate object baru pake code
                    PictureBox picture = new PictureBox();
                    string absolutePath = Path.Combine(currentDirectory, "gambar/" + item.Url);
                    picture.Image = Image.FromFile(absolutePath);
                    picture.SizeMode = PictureBoxSizeMode.StretchImage;
                    picture.Size = new Size(pbWidth, pbHeight);
                    picture.Location = new Point(curCol * (pbWidth + horizontalSpacing), curRow * (pbHeight + verticalSpacing));
                    lpb.Add(picture);

                    Label label = new Label();
                    label.Text = item.Name;
                    label.Location = new Point(curCol * (pbWidth + horizontalSpacing), (picture.Location.Y + pbHeight));
                    lblNamaBarang.Add(label);

                    Label labelPrice = new Label();
                    labelPrice.Text = item.Price.ToString();
                    labelPrice.Location = new Point(curCol * (pbWidth + horizontalSpacing), (label.Location.Y + label.Size.Height));
                    lblHargaBarang.Add(labelPrice);


                    Button btnAddToCart = new Button();
                    btnAddToCart.Text = "Add to Cart";
                    btnAddToCart.Location = new Point(curCol * (pbWidth + horizontalSpacing), (labelPrice.Location.Y + label.Size.Height));
                    listBtn.Add(btnAddToCart);

                    //Bikin even handler pake lambda function
                    btnAddToCart.Click += (senders, events) =>
                    {
                        bool checkExist = false;
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            if (dt.Rows[i]["Item Name"].ToString() == item.Name)
                            {
                                int qty = Convert.ToInt32(dt.Rows[i]["Quantity"]) + 1;
                                dt.Rows[i]["Quantity"] = qty;
                                dt.Rows[i]["Total"] = qty * item.Price;

                                checkExist = true;
                                break;
                            }
                        }
                        if (!checkExist)
                        {
                            dt.Rows.Add(item.Name, 1, item.Price, item.Price);
                        }
                        dgCart.DataSource = dt;
                        CalSubTotal();
                    };

                    // masukin object ke form
                    this.Controls.Add(picture);
                    this.Controls.Add(label);
                    this.Controls.Add(labelPrice);
                    this.Controls.Add(btnAddToCart);

                    curCol++;

                    if (curCol >= maxCol)
                    {
                        curCol = 0;
                        curRow++;
                    }
                }
            }
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteObject();
            lblUploadImage.Visible = false;
            btnUpload.Visible = false;
            pbAdd.Visible = false;
            lblAddItem.Visible = false;
            tbAddName.Visible = false;
            tbAddPrice.Visible = false;
            lblItemPrice.Visible = false;
            btnAddCart.Visible = false;
            string currentDirectory = Directory.GetCurrentDirectory();
            foreach (Item item in listItem)
            {
                if (item.Type == "Shoes")
                {
                    // Generate object baru pake code
                    PictureBox picture = new PictureBox();
                    string absolutePath = Path.Combine(currentDirectory, "gambar/" + item.Url);
                    picture.Image = Image.FromFile(absolutePath);
                    picture.SizeMode = PictureBoxSizeMode.StretchImage;
                    picture.Size = new Size(pbWidth, pbHeight);
                    picture.Location = new Point(curCol * (pbWidth + horizontalSpacing), curRow * (pbHeight + verticalSpacing));
                    lpb.Add(picture);

                    Label label = new Label();
                    label.Text = item.Name;
                    label.Location = new Point(curCol * (pbWidth + horizontalSpacing), (picture.Location.Y + pbHeight));
                    lblNamaBarang.Add(label);

                    Label labelPrice = new Label();
                    labelPrice.Text = item.Price.ToString();
                    labelPrice.Location = new Point(curCol * (pbWidth + horizontalSpacing), (label.Location.Y + label.Size.Height));
                    lblHargaBarang.Add(labelPrice);


                    Button btnAddToCart = new Button();
                    btnAddToCart.Text = "Add to Cart";
                    btnAddToCart.Location = new Point(curCol * (pbWidth + horizontalSpacing), (labelPrice.Location.Y + label.Size.Height));
                    listBtn.Add(btnAddToCart);

                    //Bikin even handler pake lambda function
                    btnAddToCart.Click += (senders, events) =>
                    {
                        bool checkExist = false;
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            if (dt.Rows[i]["Item Name"].ToString() == item.Name)
                            {
                                int qty = Convert.ToInt32(dt.Rows[i]["Quantity"]) + 1;
                                dt.Rows[i]["Quantity"] = qty;
                                dt.Rows[i]["Total"] = qty * item.Price;

                                checkExist = true;
                                break;
                            }
                        }
                        if (!checkExist)
                        {
                            dt.Rows.Add(item.Name, 1, item.Price, item.Price);
                        }
                        dgCart.DataSource = dt;
                        CalSubTotal();
                    };

                    // masukin object ke form
                    this.Controls.Add(picture);
                    this.Controls.Add(label);
                    this.Controls.Add(labelPrice);
                    this.Controls.Add(btnAddToCart);

                    curCol++;

                    if (curCol >= maxCol)
                    {
                        curCol = 0;
                        curRow++;
                    }
                }
            }
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteObject();
            lblUploadImage.Visible = false;
            btnUpload.Visible = false;
            pbAdd.Visible = false;
            lblAddItem.Visible = false;
            tbAddName.Visible = false;
            tbAddPrice.Visible = false;
            lblItemPrice.Visible = false;
            btnAddCart.Visible = false;
            string currentDirectory = Directory.GetCurrentDirectory();
            foreach (Item item in listItem)
            {
                if (item.Type == "Jewelleries")
                {
                    // Generate object baru pake code
                    PictureBox picture = new PictureBox();
                    string absolutePath = Path.Combine(currentDirectory, "gambar/" + item.Url);
                    picture.Image = Image.FromFile(absolutePath);
                    picture.SizeMode = PictureBoxSizeMode.StretchImage;
                    picture.Size = new Size(pbWidth, pbHeight);
                    picture.Location = new Point(curCol * (pbWidth + horizontalSpacing), curRow * (pbHeight + verticalSpacing));
                    lpb.Add(picture);

                    Label label = new Label();
                    label.Text = item.Name;
                    label.Location = new Point(curCol * (pbWidth + horizontalSpacing), (picture.Location.Y + pbHeight));
                    lblNamaBarang.Add(label);

                    Label labelPrice = new Label();
                    labelPrice.Text = item.Price.ToString();
                    labelPrice.Location = new Point(curCol * (pbWidth + horizontalSpacing), (label.Location.Y + label.Size.Height));
                    lblHargaBarang.Add(labelPrice);


                    Button btnAddToCart = new Button();
                    btnAddToCart.Text = "Add to Cart";
                    btnAddToCart.Location = new Point(curCol * (pbWidth + horizontalSpacing), (labelPrice.Location.Y + label.Size.Height));
                    listBtn.Add(btnAddToCart);

                    //Bikin even handler pake lambda function
                    btnAddToCart.Click += (senders, events) =>
                    {
                        bool checkExist = false;
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            if (dt.Rows[i]["Item Name"].ToString() == item.Name)
                            {
                                int qty = Convert.ToInt32(dt.Rows[i]["Quantity"]) + 1;
                                dt.Rows[i]["Quantity"] = qty;
                                dt.Rows[i]["Total"] = qty * item.Price;

                                checkExist = true;
                                break;
                            }
                        }
                        if (!checkExist)
                        {
                            dt.Rows.Add(item.Name, 1, item.Price, item.Price);
                        }
                        dgCart.DataSource = dt;
                        CalSubTotal();
                    };

                    // masukin object ke form
                    this.Controls.Add(picture);
                    this.Controls.Add(label);
                    this.Controls.Add(labelPrice);
                    this.Controls.Add(btnAddToCart);

                    curCol++;

                    if (curCol >= maxCol)
                    {
                        curCol = 0;
                        curRow++;
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(coba >=0 && coba < dgCart.Rows.Count)
            {
                dt.Rows.RemoveAt(coba);
                dgCart.DataSource = dt;
            }
            CalSubTotal();
            
        }

        private void dgCart_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            coba = e.RowIndex;
        }
    }
}
