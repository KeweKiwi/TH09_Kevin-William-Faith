﻿namespace TH09_Kevin_William_Faith
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuitem = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgCart = new System.Windows.Forms.DataGridView();
            this.lblSub = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.tbSub = new System.Windows.Forms.TextBox();
            this.tbTot = new System.Windows.Forms.TextBox();
            this.lblUploadImage = new System.Windows.Forms.Label();
            this.tbAddName = new System.Windows.Forms.TextBox();
            this.tbAddPrice = new System.Windows.Forms.TextBox();
            this.btnUpload = new System.Windows.Forms.Button();
            this.lblAddItem = new System.Windows.Forms.Label();
            this.lblItemPrice = new System.Windows.Forms.Label();
            this.btnAddCart = new System.Windows.Forms.Button();
            this.pbAdd = new System.Windows.Forms.PictureBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.menuitem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAdd)).BeginInit();
            this.SuspendLayout();
            // 
            // menuitem
            // 
            this.menuitem.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuitem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accesToolStripMenuItem,
            this.otherToolStripMenuItem});
            this.menuitem.Location = new System.Drawing.Point(0, 0);
            this.menuitem.Name = "menuitem";
            this.menuitem.Size = new System.Drawing.Size(1196, 30);
            this.menuitem.TabIndex = 0;
            this.menuitem.Tag = "Fixed";
            this.menuitem.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtsToolStripMenuItem,
            this.shirtsToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(86, 26);
            this.topWearToolStripMenuItem.Tag = "Fixed";
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtsToolStripMenuItem
            // 
            this.tShirtsToolStripMenuItem.Name = "tShirtsToolStripMenuItem";
            this.tShirtsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.tShirtsToolStripMenuItem.Text = "T-Shirts";
            this.tShirtsToolStripMenuItem.Click += new System.EventHandler(this.tShirtsToolStripMenuItem_Click);
            // 
            // shirtsToolStripMenuItem
            // 
            this.shirtsToolStripMenuItem.Name = "shirtsToolStripMenuItem";
            this.shirtsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.shirtsToolStripMenuItem.Text = "Shirts";
            this.shirtsToolStripMenuItem.Click += new System.EventHandler(this.shirtsToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(111, 26);
            this.bottomWearToolStripMenuItem.Tag = "Fixed";
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.pantsToolStripMenuItem.Tag = "";
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accesToolStripMenuItem
            // 
            this.accesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accesToolStripMenuItem.Name = "accesToolStripMenuItem";
            this.accesToolStripMenuItem.Size = new System.Drawing.Size(99, 26);
            this.accesToolStripMenuItem.Tag = "Fixed";
            this.accesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.shoesToolStripMenuItem.Tag = "";
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.jewelleriesToolStripMenuItem.Tag = "";
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // otherToolStripMenuItem
            // 
            this.otherToolStripMenuItem.Name = "otherToolStripMenuItem";
            this.otherToolStripMenuItem.Size = new System.Drawing.Size(66, 26);
            this.otherToolStripMenuItem.Tag = "";
            this.otherToolStripMenuItem.Text = "Others";
            this.otherToolStripMenuItem.Click += new System.EventHandler(this.otherToolStripMenuItem_Click);
            // 
            // dgCart
            // 
            this.dgCart.AllowUserToAddRows = false;
            this.dgCart.AllowUserToDeleteRows = false;
            this.dgCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCart.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgCart.Location = new System.Drawing.Point(676, 46);
            this.dgCart.MultiSelect = false;
            this.dgCart.Name = "dgCart";
            this.dgCart.RowHeadersVisible = false;
            this.dgCart.RowHeadersWidth = 51;
            this.dgCart.RowTemplate.Height = 24;
            this.dgCart.Size = new System.Drawing.Size(508, 236);
            this.dgCart.TabIndex = 1;
            this.dgCart.Tag = "Fixed";
            this.dgCart.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgCart_CellClick);
            // 
            // lblSub
            // 
            this.lblSub.AutoSize = true;
            this.lblSub.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub.Location = new System.Drawing.Point(677, 333);
            this.lblSub.Name = "lblSub";
            this.lblSub.Size = new System.Drawing.Size(115, 24);
            this.lblSub.TabIndex = 2;
            this.lblSub.Tag = "Fixed";
            this.lblSub.Text = "Sub-Total";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(726, 371);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(66, 24);
            this.lblTotal.TabIndex = 3;
            this.lblTotal.Tag = "Fixed";
            this.lblTotal.Text = "Total";
            // 
            // tbSub
            // 
            this.tbSub.Font = new System.Drawing.Font("Square721 BT", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSub.Location = new System.Drawing.Point(825, 336);
            this.tbSub.Name = "tbSub";
            this.tbSub.Size = new System.Drawing.Size(183, 29);
            this.tbSub.TabIndex = 4;
            this.tbSub.Tag = "Fixed";
            // 
            // tbTot
            // 
            this.tbTot.Font = new System.Drawing.Font("Square721 BT", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTot.Location = new System.Drawing.Point(825, 374);
            this.tbTot.Name = "tbTot";
            this.tbTot.Size = new System.Drawing.Size(183, 29);
            this.tbTot.TabIndex = 5;
            this.tbTot.Tag = "Fixed";
            // 
            // lblUploadImage
            // 
            this.lblUploadImage.AutoSize = true;
            this.lblUploadImage.Location = new System.Drawing.Point(29, 88);
            this.lblUploadImage.Name = "lblUploadImage";
            this.lblUploadImage.Size = new System.Drawing.Size(93, 16);
            this.lblUploadImage.TabIndex = 6;
            this.lblUploadImage.Tag = "Fixed";
            this.lblUploadImage.Text = "Upload Image";
            // 
            // tbAddName
            // 
            this.tbAddName.Location = new System.Drawing.Point(215, 149);
            this.tbAddName.Name = "tbAddName";
            this.tbAddName.Size = new System.Drawing.Size(100, 22);
            this.tbAddName.TabIndex = 7;
            this.tbAddName.Tag = "Fixed";
            this.tbAddName.TextChanged += new System.EventHandler(this.tbAddName_TextChanged);
            // 
            // tbAddPrice
            // 
            this.tbAddPrice.Location = new System.Drawing.Point(215, 218);
            this.tbAddPrice.Name = "tbAddPrice";
            this.tbAddPrice.Size = new System.Drawing.Size(100, 22);
            this.tbAddPrice.TabIndex = 8;
            this.tbAddPrice.Tag = "Fixed";
            this.tbAddPrice.TextChanged += new System.EventHandler(this.tbAddPrice_TextChanged);
            this.tbAddPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbAddPrice_KeyPress);
            // 
            // btnUpload
            // 
            this.btnUpload.Location = new System.Drawing.Point(140, 85);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(75, 23);
            this.btnUpload.TabIndex = 9;
            this.btnUpload.Tag = "Fixed";
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // lblAddItem
            // 
            this.lblAddItem.AutoSize = true;
            this.lblAddItem.Location = new System.Drawing.Point(215, 130);
            this.lblAddItem.Name = "lblAddItem";
            this.lblAddItem.Size = new System.Drawing.Size(72, 16);
            this.lblAddItem.TabIndex = 10;
            this.lblAddItem.Tag = "Fixed";
            this.lblAddItem.Text = "Item Name";
            // 
            // lblItemPrice
            // 
            this.lblItemPrice.AutoSize = true;
            this.lblItemPrice.Location = new System.Drawing.Point(215, 199);
            this.lblItemPrice.Name = "lblItemPrice";
            this.lblItemPrice.Size = new System.Drawing.Size(66, 16);
            this.lblItemPrice.TabIndex = 11;
            this.lblItemPrice.Tag = "Fixed";
            this.lblItemPrice.Text = "Item Price";
            // 
            // btnAddCart
            // 
            this.btnAddCart.Location = new System.Drawing.Point(218, 275);
            this.btnAddCart.Name = "btnAddCart";
            this.btnAddCart.Size = new System.Drawing.Size(97, 23);
            this.btnAddCart.TabIndex = 12;
            this.btnAddCart.Tag = "Fixed";
            this.btnAddCart.Text = "Add to cart";
            this.btnAddCart.UseVisualStyleBackColor = true;
            this.btnAddCart.Click += new System.EventHandler(this.btnAddCart_Click);
            // 
            // pbAdd
            // 
            this.pbAdd.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pbAdd.Location = new System.Drawing.Point(32, 130);
            this.pbAdd.Name = "pbAdd";
            this.pbAdd.Size = new System.Drawing.Size(162, 168);
            this.pbAdd.TabIndex = 13;
            this.pbAdd.TabStop = false;
            this.pbAdd.Tag = "Fixed";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(676, 289);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1196, 450);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.pbAdd);
            this.Controls.Add(this.btnAddCart);
            this.Controls.Add(this.lblItemPrice);
            this.Controls.Add(this.lblAddItem);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.tbAddPrice);
            this.Controls.Add(this.tbAddName);
            this.Controls.Add(this.lblUploadImage);
            this.Controls.Add(this.tbTot);
            this.Controls.Add(this.tbSub);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.dgCart);
            this.Controls.Add(this.menuitem);
            this.MainMenuStrip = this.menuitem;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuitem.ResumeLayout(false);
            this.menuitem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAdd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuitem;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otherToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgCart;
        private System.Windows.Forms.Label lblSub;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox tbSub;
        private System.Windows.Forms.TextBox tbTot;
        private System.Windows.Forms.ToolStripMenuItem tShirtsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.Label lblUploadImage;
        private System.Windows.Forms.TextBox tbAddName;
        private System.Windows.Forms.TextBox tbAddPrice;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Label lblAddItem;
        private System.Windows.Forms.Label lblItemPrice;
        private System.Windows.Forms.Button btnAddCart;
        private System.Windows.Forms.PictureBox pbAdd;
        private System.Windows.Forms.Button btnDelete;
    }
}

